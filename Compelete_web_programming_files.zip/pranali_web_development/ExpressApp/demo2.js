var express = require('express')

var app = express()

//app.method(incoming-urlencoded, callback-func)

var persons =[
    {pid :101, pname:'aaaa', age:45},
    {pid :102, pname:'bbbb', age:35},
    {pid :103, pname:'cccc', age:25},
]

// app.get("/",function(req, resp){
//     resp.sendFile("./user.html",{root:__dirname})
// })

//http://localhost:3000/user/101

//Traditional web application
app.get("/user/:uid",function(req,resp){
    var flag = false
    var pid = req.params.uid
    var pers
    // var pid = req.query.pid
    for(person of persons){
        if(person.pid == pid){
            flag = true
            pers = person
            
        }
    }
    if(flag){
        resp.send(pers)
    }
    else{
        resp.send("Person with pid " + pid + " not found ")
    }
    
   
})

app.get("/users",(req, resp)=>{
    resp.send(persons)
})



app.listen(3000, function(){
    console.log("Server running on http://localhost:3000")
})