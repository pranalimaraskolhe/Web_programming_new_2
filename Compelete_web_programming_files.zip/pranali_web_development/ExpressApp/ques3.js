var express = require('express')
var app = express()
var bodyParser = require("body-parser")
app.use(bodyParser.urlencoded({extended:false}))

var data = [
    {username:'Pranali',Password:'Pranali@123'},
    {username:'Sejal',Password:'Sejal@123'},
    {username:'Harsha',Password:'Harsha@123'},
    {username:'Aishwarya',Password:'Ash@123'}
]

app.get('/', function (req, res) {
  res.sendFile("ques3_login.html",{root:__dirname})
})

app.post("/process",(req,res)=>{
    var uname = req.body.uname
    var pass =  req.body.pass
    var flag = 0
    
    for(i=0; i<data.length; i++){
        if((data[i].username == uname) && (data[i].Password == pass)){
            flag = true
        
        }
    }
    if(flag){
        res.sendFile("succes.html",{root:__dirname})
        
    }
    else{
        res.sendFile("failure.html",{root:__dirname})
    }
})

app.listen(4000,()=>{
    console.log("Server is running on http://localhost:4000")
})