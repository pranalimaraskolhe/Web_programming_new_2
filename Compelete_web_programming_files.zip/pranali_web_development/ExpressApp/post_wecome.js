var express = require('express')

var app = express()
var bodyParser = require("body-parser")
app.use(bodyParser.urlencoded({extended:false}))

app.get("/",(req, resp)=>{
    resp.sendFile("post_welcome.html", {root:__dirname})
})

app.post("/process",(req,resp)=>{
    var fn = req.body.fname
    var ln = req.body.lname

    resp.send("Welcome "+fn+", "+ln)
})

app.listen(3000, function(){
    console.log("Server running on http://localhost:3000")
})