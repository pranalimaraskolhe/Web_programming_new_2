var express = require('express')

var app = express()

app.get("/",(req, resp)=>{
    resp.sendFile("demo_welcome.html", {root:__dirname})
})

app.get("/process",(req,resp)=>{
    var fn = req.query.fname
    var ln = req.query.lname

    resp.send("Welcome "+fn+", "+ln)
})

app.listen(3000, function(){
    console.log("Server running on http://localhost:3000")
})