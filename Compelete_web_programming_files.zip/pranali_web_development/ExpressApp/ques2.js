var express = require('express')

var app = express()

app.get("/",(req,resp)=>{
    resp.sendFile("ques2.html",{root:__dirname})
})

app.get("/process",(req,resp)=>{
    var p = req.query.principle
    var r = req.query.rate
    var t = req.query.time

    var si = (p*r*t)/100

    resp.send("Simple Interest is "+si)
})

app.listen(4000,()=>{
    console.log("Server is running on http://localhost:4000")
})