var express = require('express')

var app = express()

//app.method(incoming-urlencoded, callback-func)


app.get("/",function(req, resp){
    resp.send("<h1>Welcome to Express!</h1>")
})

app.get("/user",function(req, resp){
    var user = {uname :"Pranali", module: "Express", grade: "A"}
    resp.send(user)
})

app.get("/names",function(req, resp){
    var names = ["Pranali","Nishant","Akansha"]
    resp.send(names)
})

app.get("/file",function(req, resp){
    resp.sendFile("./welcome.html",{root:__dirname})
})


app.listen(3000, function(){
    console.log("Server running on http://localhost:3000")
})