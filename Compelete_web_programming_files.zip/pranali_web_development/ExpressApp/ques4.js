var express = require('express')

var app = express()
var bodyParser = require("body-parser")
app.use(bodyParser.urlencoded({extended:false}))

var data =[]

app.get("/",(req,res)=>{
    res.sendFile("ques4.html",{root:__dirname})
})

app.post("/process",(req,res)=>{
    
    var uname = req.body.uname
    var pass = req.body.pass
    
    data.push({uname,pass})
    res.send(data)

    //res.sendFile("ques4.html",{root:__dirname})
})

app.listen(4000,()=>{
    console.log("Server is running on http://localhost:4000")
})

