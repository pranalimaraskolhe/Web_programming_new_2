nameLength = () =>{
    var arr = ["Joy","Meena","Anne","Xi","Veena","Vanitha"]
    for(i of arr){
        if(i.length>=5){
            console.log(i)
        }
    }
}
nameLength()