import java.util.Scanner;

public class Ques11 {
	public static void main(String[] args) {
		
		int arr[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
		
		
		/*Scanner sc = new Scanner(System.in);
		System.out.println("Enter number: ");
		int num = sc.nextInt();
		int arr[] = new int[num];
		
		for(int i=0; i<arr.length; i++) {
			System.out.println("Enter elements: ");
			arr[i] = sc.nextInt();
			
			
		}
		
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}*/
		
		
		
		int sum = 0;
		int count = 0;
		
		for(int ele : arr) {
			sum += ele; 
		}
		
		int avg = sum/arr.length;
		
		for(int ele : arr) {
			if(ele > avg) {
				count++;
				
			}
		}
		
		System.out.println("The average is :" + avg);
		System.out.println("The number which are greater than average " + count);
		
		
	}
	
}
