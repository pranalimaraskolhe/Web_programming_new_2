
public abstract class Shape {
	
	String color;

	public String getColor() { //concrete method
		return color;
	}

	public void setColor(String color) { //concrete method
		this.color = color;
	}
	
	public abstract void draw(); //Abstract Method
	
}

