
public class ArrayDemo {
	public static void main(String[] args) {
		/*int arr[] = new int[3];
		
		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;
		
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}
		
		for(int ele : arr) {
			System.out.println(ele);
		}*/
		
		/*int sum = 0;
		int arr[] = {1,2,3,4,5};
		for(int i=0; i<arr.length; i++) {
			sum += arr[i];
			
		}
		System.out.println(sum);*/
		
		
		/*float temp[] = {23.f,56.7f,34.4f,22.1f,0.0f};
		for(float t : temp) {
			System.out.println(t);
		}*/
		
		
		//char [] charr = new char[10];
		/*char[] charr = {'a','m','3','&',' ', '@'};
		
		for(char ele : charr) {
			System.out.println(ele);
		}*/
		
		/*String[] names = new String[3];
		names[0] = "aaaa"*/
		
		/*String[] names = {"sejal","ash","pranali","harsha"};
		for(String ele : names) {
			System.out.println(ele);
		}*/
		
		Box b1 = new Box(1,2,3);
		Box b2 = new Box(10,20,30);
		Box b3 = new Box(100,200,300);
		
		Box[] barr = {b1,b2,b3};
		
		/*Box[] barr = new Box[3];
		
		barr[0] = new Box(1,2,3);
		barr[1] = new Box(10,20,30);
		barr[2] = new Box(100,200,300);*/
		
		for(Box ele : barr) {
			ele.displayDim();
		}
		
	}
}
