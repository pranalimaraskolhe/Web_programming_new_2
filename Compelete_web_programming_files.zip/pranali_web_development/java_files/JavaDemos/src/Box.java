
public class Box {
	
	int length;
	int width;
	int height;
	
	
	public Box() {}

	public Box(int length, int width, int height) {
		this.length = length;
		this.width = width;
		this.height = height;
	}


	public void displayDim() {
		System.out.println("Box [length=" + length + ", width=" + width + ", height=" + height + "]");
	}
	
	public int calcVolume() {
		//int vol;
		return length * width * height;
		//vol = length * width * height;
		//return vol;
	}

	/*public static void main(String[] args) {
		Box b1 = new Box(10, 20, 30);
		b1.displayDim();*/
		//System.out.println(b1);
		
		//Box b2 = new Box();
		//b2.displayDim();
	//}
}
