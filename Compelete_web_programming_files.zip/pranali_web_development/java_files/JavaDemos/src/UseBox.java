
public class UseBox {
	public static void main(String[] args) {
		Box b1 = new Box(10,20,30);
		System.out.println(b1.length + " " + b1.width + " " + b1.height);
	}
}
