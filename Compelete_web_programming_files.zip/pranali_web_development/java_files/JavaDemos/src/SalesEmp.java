
public class SalesEmp extends WageEmp{
	private int comm;

	public SalesEmp(int id, String ename, int hrs, int rate, int comm) {
		super(id, ename, hrs, rate);
		this.comm = comm;
	}
	
	/*public int calSalary() {
		return super.calSalary() + comm;
	}*/
	
	public static void main(String[] args) {
		//SalesEmp emp1 = new SalesEmp(1001,"Pranali",10,100,500);
		
		/*emp1.displayEmpDetails();
		System.out.println("Sal is : " + emp1.calSalary());*/
		
		
		Emp e1 = new WageEmp(1001,"aaaa",20,12000);
		((WageEmp)e1).calSalary();
		
		
		Emp e2 = new WageEmp(1002,"bbb",21,14000);
		((WageEmp)e2).calSalary();
	}
}
