
public class Circle extends Point{
	
	public void draw() {
		System.out.println("Drawing a circle!!");
	}
	
	public static void main(String[] args) {
		Shape s1 = new Point();
		Shape s2 = new Circle();
		
		
		s1.draw();
		s2.draw();
	}
}
