
public class Person {
	
	private int pid;
	private String pname, gender;
	private float age;
	
	public Person() {
		
	}
	
	public Person(int pid, String pname, String gender, float age) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.gender = gender;
		this.age = age;
	}


	public String toString() {
		return "Person [pid=" + pid + ", pname=" + pname + ", gender=" + gender + ", age=" + age + "]";
	}
	
	public static void main(String[] args) {
		Person p1 = new Person(101,"Pranali","female",23.4f);
		System.out.println(p1);                         
	}
	
	
}
