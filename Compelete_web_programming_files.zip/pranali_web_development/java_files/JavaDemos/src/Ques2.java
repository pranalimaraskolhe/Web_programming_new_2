import java.util.Scanner;

public class Ques2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the interger:");
		int num = sc.nextInt();
		System.out.println("Enter String: ");
		String uname = sc.next();
		
		System.out.println();
		
		for(int i=0; i<3; i++) {
			System.out.println(num);
			System.out.println(uname);
		}
	}
}
