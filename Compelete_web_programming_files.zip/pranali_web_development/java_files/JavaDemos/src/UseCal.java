
public class UseCal {
	public static void main(String[] args) {
		System.out.println(Cal.add(10, 20));
		System.out.println(Cal.add("aaa", "bbb"));
		System.out.println(Cal.add(2.3f, 12.5f));
		System.out.println(Cal.add(10, 20, 30));
	}
}
