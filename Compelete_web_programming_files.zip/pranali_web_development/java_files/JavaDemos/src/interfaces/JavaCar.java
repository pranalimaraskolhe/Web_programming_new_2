package interfaces;

public class JavaCar extends Accelerator implements Breakable, Audible{

	
	public void brake() {
		System.out.println("Stopping the car!");
		
	}
	
	
	public static void main(String[] args) {
		JavaCar car = new JavaCar();
		car.accelerate();
		car.brake();
		car.playmusic();
	}


	public void playmusic() {
		System.out.println("Play Music!");
		
	}

}
