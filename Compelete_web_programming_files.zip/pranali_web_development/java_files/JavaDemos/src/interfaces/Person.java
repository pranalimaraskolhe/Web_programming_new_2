package interfaces;

public class Person {

}
