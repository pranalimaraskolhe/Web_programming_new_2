package interfaces;

public class Accelerator {

	public void accelerate() {
		System.out.println("Accelerating the car");
	}
}
