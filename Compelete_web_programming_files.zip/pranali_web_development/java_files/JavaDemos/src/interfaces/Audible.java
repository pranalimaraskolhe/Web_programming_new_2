package interfaces;

public interface Audible {
	public void playmusic();
}
