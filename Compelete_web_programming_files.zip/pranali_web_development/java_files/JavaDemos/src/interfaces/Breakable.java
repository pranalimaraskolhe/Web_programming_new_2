package interfaces;

public interface Breakable {
	
	public void brake();
	
	
}
