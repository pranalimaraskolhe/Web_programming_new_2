
public class Ques9 {
	//public int arr[] = {10,5,63,59,77,51,49,63,7,2};
	
	public static void subarr(int startIndex, int endIndex, int arr[]) {
		for(int i=startIndex; i<endIndex; i++) {
			System.out.println(arr[i]);
		}
	}
	
	public static void main(String[] args) {
		int arr[] = {10,5,63,59,77,51,49,63,7,2};
		Ques9.subarr(1,5,arr);
	}
	
}
