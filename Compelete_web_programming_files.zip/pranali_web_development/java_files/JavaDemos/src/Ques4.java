import java.util.Scanner;

public class Ques4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter multiplyer: ");
		int mutiplyer = sc.nextInt();
		//System.out.println("Enter Multiplicant: ");
		//int multipicant = sc.nextInt();
		for(int i=0; i<=10; i++) {
			System.out.println('2' + " * " +  " " + i + " = " + (i*mutiplyer));
		}
	}
}
