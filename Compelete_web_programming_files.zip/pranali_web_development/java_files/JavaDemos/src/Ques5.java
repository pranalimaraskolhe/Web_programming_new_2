import java.util.Scanner;

public class Ques5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number1:");
		int num1 = sc.nextInt();
		System.out.println("Enter Number2:");
		int num2 = sc.nextInt();
		System.out.println("Enter operator:");
		String op = sc.next();
		
		switch(op) {
		case "+": 
			System.out.println("Addition is :" + (num1+num2));
			break;
			
		case "-":
			System.out.println("Subraction is :" +(num1-num2));
			break;
			
		case "*":
			System.out.println("Multiplication is:" + (num1*num2));
			break;
			
		case "/":
			System.out.println("Division is :" + (num1/num2));
			break;
			
		default:
			System.out.println("Inavlid");
		}
	}
}
