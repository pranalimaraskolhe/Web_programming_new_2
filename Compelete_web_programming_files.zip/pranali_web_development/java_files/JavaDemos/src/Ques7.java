import java.util.Scanner;

public class Ques7 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Weight: ");
		int weight = sc.nextInt();
		
		System.out.println("Enter Height: ");
		float height = sc.nextFloat();
		float convert_height = height/100;
		
		float bmi = weight/(convert_height * convert_height);
		
		System.out.println("Your BMI is :" + bmi);
		
		if(bmi<18.5) {
			System.out.println("Underweight");
		}
		else if(18.5<bmi && bmi<25.0 ) {
			System.out.println("Normal");	
		}
		else if(25.0<bmi && bmi<30.0) {
			System.out.println("Overweight");
		}
		else {
			System.out.println("Obese");
		}
	}
}
