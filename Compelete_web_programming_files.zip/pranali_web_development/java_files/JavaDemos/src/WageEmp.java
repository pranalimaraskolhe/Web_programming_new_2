
public class WageEmp extends Emp{
	
	private int hrs, rate;
	
	public WageEmp(int id,String ename, int hrs, int rate) {
		super(id, ename);
		this.hrs = hrs;
		this.rate = rate;
	}
	
	public int calSalary() {
		return hrs * rate;
	}
	
	public static void main(String[] args) {
		WageEmp wel = new WageEmp(1001,"Harsha", 10, 100);
		
		wel.displayEmpDetails();
		System.out.println("Sal is : " + wel.calSalary());
	}
}
