//static polymorphism -----> method overloading

// method overloading : type of params or number of paras diff
//all overloading methods are in same class

public class Cal {
	public static int add(int a, int b) {
		return a+b;
	}
	
	
	public static String add(String a, String b) {
		return a+b;
	}
	
	public static float add(float a, float b) {
		return a+b;
	}
	
	public static int add(int a, int b,int c) {
		return a+b+c;
	}
	

	public static void main(String[] args) {
		//Cal cal = new Cal();
		System.out.println(add(10, 20));
		System.out.println(add("aaa", "bbb"));
		System.out.println(add(2.3f, 12.5f));
		System.out.println(add(10, 20, 30));
	}
}
