import java.util.Scanner;

public class GreatestOfThree {
	
	public static void main(String[] args) {
		Scanner sp = new Scanner(System.in);
		System.out.println("Enter number1");
		int num1 = sp.nextInt();
		System.out.println("Enter number2");
		int num2 = sp.nextInt();
		System.out.println("Enter number3");
		int num3 = sp.nextInt();
		
		if(num1>num2 && num1>num3) {
			System.out.println("Number " + num1 + " is greatest");
		}
		else if(num2>num1 && num2>num3) {
			System.out.println("Number " + num2 + " is greatest");
		}
		else {
			System.out.println("Number " + num3 + " is greatest");
		}
	}
	
}
