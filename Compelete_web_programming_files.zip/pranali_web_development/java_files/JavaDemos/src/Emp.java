
public class Emp {
	private int empId;
	private String empName;
	
	public Emp() {}
	
	public Emp(int empId, String empName) {
		this.empId = empId;
		this.empName = empName;
	}
	
	public void displayEmpDetails() {
		System.out.println("Emp [empId=" + empId + ", empName=" + empName + "]");
	}
	
	public static void main(String[] args) {
		Emp e1 = new Emp(101,"Pranali");
		System.out.println(e1);
	}
	
}
