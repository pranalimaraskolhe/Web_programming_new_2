
public class StringDemo {
	public static void main(String[] args) {
		String s1 = "hello";
		String s2 = new String("hello");
		String s3 = "Hello World";
		
		System.out.println(s1 == s2);
		System.out.println(s1 == s3);
		
		System.out.println(s3.length());
		System.out.println(s3.charAt(0));
		System.out.println(s3.indexOf("orl"));
		System.out.println(s3.toUpperCase());
		System.out.println(s3.substring(2, 5));
		
		System.out.println(s1.equals(s2));
		
		//mutable string
		/*System.out.println(s1);
		s1 += " world";
		System.out.println(s1);*/
		
		int i = 10;
		i++;
	}
	
}
