package Assigment2;

public class Date {
	int day, month, year;

	public Date(int day, int month, int year) {
		super();
		this.day = day;
		this.month = month;
		this.year = year;
		
		}

	public void setDay(int day) {
		if(day>=1 && day<=31) {
			this.day = day;
		}
		else {
			System.out.println("Day is not in between 1 to 31");
		}
	}
	
	public int getDay() {
		return this.day;
	}
	
	public void setYear(int year) {
		if(year<1984) {
			this.year = year;
		}
		else {
			System.out.println("The year must be less than 1984");
		}
		
	}
	
	public int getYear() {
		return this.year;
	}
	
	
	
	
	public void Dateformat() {
		 System.out.println("Date [day=" + day + ", month=" + month + ", year=" + year + "]");
	}


	public static void main(String[] args) {
		Date d1 = new Date(33,4,1992);
		
		d1.setDay(33);
		d1.setYear(1999);
		d1.Dateformat();
	}
}
