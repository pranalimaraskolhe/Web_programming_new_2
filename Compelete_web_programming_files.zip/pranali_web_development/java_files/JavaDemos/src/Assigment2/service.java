package Assigment2;

public class service extends Product{
	private String Startdate;
	private String Enddate;
	private String Service_engineer_name;
	
	public service(int productId, String productName,String startdate, String enddate, String service_engineer_name) {
		super(productId,productName);
		Startdate = startdate;
		Enddate = enddate;
		Service_engineer_name = service_engineer_name;
	}

	public String getStartdate() {
		return Startdate;
	}

	public void setStartdate(String startdate) {
		Startdate = startdate;
	}

	public String getEnddate() {
		return Enddate;
	}

	public void setEnddate(String enddate) {
		Enddate = enddate;
	}

	public String getService_engineer_name() {
		return Service_engineer_name;
	}

	public void setService_engineer_name(String service_engineer_name) {
		Service_engineer_name = service_engineer_name;
	}

	
	public void displaydetails() {
		System.out.println("service [Startdate=" + Startdate + ", Enddate=" + Enddate + ", Service_engineer_name="
				+ Service_engineer_name + ", getProductId =" + getProductId() + ", getProductName ="
				+ getProductName() + "]");
	}
	
	public static void main(String[] args) {
		service s1 = new service(101,"Brush","21/05/22","25/05/22","Mahesh");
		s1.displaydetails();
		}
	
}
