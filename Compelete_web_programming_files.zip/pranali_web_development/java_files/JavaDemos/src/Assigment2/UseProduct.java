package Assigment2;

public class UseProduct {
	int productId;
	String desc;
	double price;
	int NoOfUnit;
	
	
	public UseProduct(int productId, String desc, double price, int noOfUnit) {
		super();
		this.productId = productId;
		this.desc = desc;
		this.price = price;
		NoOfUnit = noOfUnit;
	}


	public void displaydetails() {
		 System.out.println("UseProduct [productId=" + productId + ", desc=" + desc + ", price=" + price + ", NoOfUnit=" + NoOfUnit + "]");
	}
	
	
	public static void main(String[] args) {

		
		UseProduct p1 = new UseProduct(101," face wash",50,5);
		UseProduct p2 = new UseProduct(102,"toothpaste",60,100);
		UseProduct p3 = new UseProduct(103,"Brush",20,5);
		UseProduct p4 = new UseProduct(104,"Hair oil",100,50);
		
		UseProduct[] arr = {p1,p2,p3,p4};
		
		for(UseProduct ele : arr) {
			ele.displaydetails();
		}
		
	}
	
	
	
}
