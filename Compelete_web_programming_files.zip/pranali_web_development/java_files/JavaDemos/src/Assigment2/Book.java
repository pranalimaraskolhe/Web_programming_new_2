package Assigment2;

public class Book {
	private int book_no;
	private String title;
	private String author;
	private float price;
	
	public Book(int book_no, String title, String author, float price) {
		super();
		this.book_no = book_no;
		this.title = title;
		this.author = author;
		this.price = price;
	}

	public int getBook_no() {
		return book_no;
	}

	public void setBook_no(int book_no) {
		this.book_no = book_no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
	public float incrPrice(double percentage) {
		float incrprice = (float) (price + percentage);
		System.out.println("The increse price is " + incrprice);
		return incrprice;
	}

	
	public void displayBookDetails() {
		System.out.println("Book [book_no=" + book_no + ", title=" + title + ", author=" + author + ", price=" + price + "]");
		
	}
	
	public static void main(String[] args) {
		Book b1 = new Book(101,"C","abc",1000);
		b1.displayBookDetails();
		b1.incrPrice(50);
	}	
}
