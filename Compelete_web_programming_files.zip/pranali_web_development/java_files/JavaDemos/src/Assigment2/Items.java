package Assigment2;

public class Items extends Product{
	private int height, width, length;
	private int warrenty;
	private int costofshipp;
	private String manfact;
	
	
	public Items(int productId, String productName,int height, int width, int length, int warrenty, int costofshipp, String manfact) {
		super(productId,productName);
		this.height = height;
		this.width = width;
		this.length = length;
		this.warrenty = warrenty;
		this.costofshipp = costofshipp;
		this.manfact = manfact;
	}


	
	public int getHeight() {
		return height;
	}



	public void setHeight(int height) {
		this.height = height;
	}



	public int getWidth() {
		return width;
	}



	public void setWidth(int width) {
		this.width = width;
	}



	public int getLength() {
		return length;
	}



	public void setLength(int length) {
		this.length = length;
	}



	public int getWarrenty() {
		return warrenty;
	}



	public void setWarrenty(int warrenty) {
		this.warrenty = warrenty;
	}



	public int getCostofshipp() {
		return costofshipp;
	}



	public void setCostofshipp(int costofshipp) {
		this.costofshipp = costofshipp;
	}



	public String getManfact() {
		return manfact;
	}



	public void setManfact(String manfact) {
		this.manfact = manfact;
	}



	public void displaydetails() {
		System.out.println(getProductId()+ " "+getProductName()+" "+this.height+" "+this.width+" "+this.length + " " + this.warrenty + " " + this.costofshipp + " " + this.manfact);
	}
	
	public static void main(String[] args) {
		Items it1 = new Items(101,"Box",7,30,50,3,500,"Jio");
		
		it1.displaydetails();
	}
	
}
