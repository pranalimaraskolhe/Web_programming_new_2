 package Assigment2;

import java.util.Scanner;

public class Rectangle {
	public int length, breadth,area,peri;
	

	public Rectangle() {}



	/*public Rectangle(int length, int breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}*/



	public int getLength() {
		return length;
	}



	public void setLength(int length) {
		this.length = length;
	}



	public int getBreadth() {
		return breadth;
	}



	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
	
	public int Rectarea() {
		area = (getLength() + getBreadth());
		
		return area;
	}
	
	public int RectPerimeter() {
		peri = 2*(getLength() + getBreadth());
		return peri;
				
	}

	
	public void displayArea() {
		System.out.println("Area of rectangle: " + area);
	}
	
	public void displayPeri() {
		System.out.println("Perimeter of rectangle: " + peri);
	}
	
	public static void main(String[] args) {
		Rectangle rect1 = new Rectangle();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Length:  ");
		rect1.setLength(sc.nextInt());
		System.out.println("Enter Breadth: ");
		rect1.setBreadth(sc.nextInt());
		rect1.Rectarea();
		rect1.displayArea();
		rect1.RectPerimeter();
		rect1.displayPeri();
		
		}
	
	
}
