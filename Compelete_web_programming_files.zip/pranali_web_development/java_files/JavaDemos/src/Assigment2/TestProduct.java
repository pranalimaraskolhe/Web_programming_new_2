package Assigment2;

public class TestProduct {

	public static void main(String[] args) {
		Product p= new Product(1,"box");
		Items item = new Items(2,"boxes",7,30,50,3,500,"Jio");
		
		
		
		p.displaydetails();
		
		item.displaydetails();
		
		
		System.out.println(item.getProductName());
		
		
		System.out.println(p.getProductId());
	
		
		//p.getHeight();
		
		item.getLength();
		
	}
	
	
}
