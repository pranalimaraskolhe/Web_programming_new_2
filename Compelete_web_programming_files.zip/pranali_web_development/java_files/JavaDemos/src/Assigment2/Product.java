package Assigment2;

public class Product {
	private int productId;
	private String productName;
	
	public Product() {}
	
	public Product(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
	}

	public void displaydetails() {
		System.out.println("Inheritance [productId=" + productId + ", productName=" + productName + "]");
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	
	
	/*public static void main(String[] args) {
		Product pro1 = new Product(101,"Shirt");
		pro1.displaydetails();
		
	}*/
	
	
}


