package Assigment2;

import java.util.Scanner;


public class Ques5 {
	private int book_no;
	private String title;
	private String author;
	private float price;
	public static int bookcount = 0;
	
	public Ques5() {}
	
	public Ques5(int book_no, String title, String author, float price) {
		super();
		this.book_no = book_no;
		this.title = title;
		this.author = author;
		this.price = price;
		bookcount++;
	}
	
	public static void intialize() {
		bookcount =  0;
	}

	public static int getBookCount() {
		return bookcount;
	}	
	public int getBook_no() {
		return book_no;
	}

	public void setBook_no(int book_no) {
		this.book_no = book_no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
	public void incrPrice() {
		float incrprice = (float) (price + (price* 5/100));
		System.out.println("The increse price is " + incrprice);
		
	}

	
	public void displayBookDetails() {
		
		//System.out.println(getBookCount());
		System.out.println("Book [book_no=" + book_no + ", title=" + title + ", author=" + author + ", price=" + price + ", BookCount=" + bookcount +"]");
		
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Ques5 [] arr = new Ques5[2];
		
		
		for(int i=0; i<arr.length; i++) {
			System.out.println("Enter the book data"+(i+1));

			System.out.println("Enter Book no: ");
			int book_no = sc.nextInt();
			System.out.println("Enter the title of book");
			String title = sc.next();
			System.out.println("Enter the author");
			String author = sc.next();
			System.out.println("Enter the price");
			float price = sc.nextFloat();
			
			arr[i] = new Ques5(book_no , title, author, price);
			
		}
		
		boolean found = false;
		
		System.out.println("Enter the book number which you want to search: ");
		int BookSearch = sc.nextInt();
		
		for(Ques5 i : arr) {
			if(i.book_no == BookSearch) {
				i.displayBookDetails();
				found = true;
			}
			
			if(!found) {
				System.out.println("Book not found");
			}
		}
		
		
		for(Ques5 i : arr) {
			i.incrPrice();
			
		}
		
		System.out.println("The counter of Books is: " + Ques5.getBookCount());
	}	
}
