package Exam;

import java.util.Scanner;

public class ExamQue3 {
	  public static void main(String[] args) {
	    //String sentence = "Hello World Java Program";
	    Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a sentence:");
        String input = scanner.nextLine();
	    String[] words = input.split(" ");
	    StringBuilder reversedSentence = new StringBuilder();

	    for (String word : words) {
	      StringBuilder reversedWord = new StringBuilder(word).reverse();
	      reversedSentence.append(reversedWord).append(" ");
	    }

	    System.out.println(reversedSentence.toString().trim());
	  }
	}
