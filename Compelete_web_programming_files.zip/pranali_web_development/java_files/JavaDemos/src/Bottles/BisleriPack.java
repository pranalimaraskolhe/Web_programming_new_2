package Bottles;

interface BisleriBottle {
	public static float getcost() {
		float inr = 15.3600f;
		return inr;
		
	}
	
}

 class SmallBottle implements BisleriBottle{
	public float getcost() {
		return 10.5f;
	}
}
 
 
 class LargeBottle implements BisleriBottle{
		public float getcost() {
			return 15.6f;
		}
	}


public class BisleriPack {
	BisleriBottle bottletype;
	int quantity;
	
	public BisleriPack(BisleriBottle bottletype, int quantity) {
		super();
		this.bottletype = bottletype;
		this.quantity = quantity;
	}
	
	public float price() {
		//float totalPrice = this.quantity * getcost();
		return BisleriBottle.getcost()*quantity;		
	}
	
	public static void main(String[] args) {
		BisleriPack[] packs = new BisleriPack[2];
		
		packs[0] = new BisleriPack(new SmallBottle(), 6);
		packs[1] = new BisleriPack(new LargeBottle(), 8);
		
		float Price = 0;
		
		for(BisleriPack pack : packs) {
			Price += pack.price();
			}
		
		System.out.println("Total Price : " + Price);
	}
	
	}
	

