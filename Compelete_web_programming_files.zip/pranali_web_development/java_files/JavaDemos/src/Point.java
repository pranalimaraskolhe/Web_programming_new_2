
public class Point extends Shape{
	
	public void draw() {
		System.out.println("Drawing a point!!");
	}
	
	public static void main(String[] args) {
		Shape s1 = new Point();
		s1.setColor("blue");
		
		s1.draw();
		System.out.println(s1.getColor());
	}
	
}
