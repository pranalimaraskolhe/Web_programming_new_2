package Assigment3;

public class IllegalSizeException extends Exception{

	public IllegalSizeException() {
		super();
		// TODO Auto-generated constructor stub
	}


	

	public IllegalSizeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	}
	

