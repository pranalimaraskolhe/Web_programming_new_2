package Assigment3;

public class Rectangle {
	double length;
	double width;
	public Rectangle(double length, double width) throws IllegalSizeException {
		if(length <= 0 && width <=0) {
			throw new IllegalSizeException("Should be grater");
		}
		this.length = length;
		this.width = width;
	}
	
	public double area() {
		return length * width;
	}
	
}
