package Assigment3;

public class TestRectangle {
	public static void main(String[] args) {
       try {
		Rectangle r1 = new Rectangle(-1,-6);
	} catch (IllegalSizeException e) {
		System.out.println(e.getMessage());
	} 
	}
}
