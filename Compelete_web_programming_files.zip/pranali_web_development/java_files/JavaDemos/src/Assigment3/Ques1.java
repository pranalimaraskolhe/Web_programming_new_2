package Assigment3;

import java.util.Scanner;

public class Ques1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = sc.next();
		int length = str.length();
		System.out.println("Length Of String: " + length);
		System.out.println("Uppercase: " + str.toUpperCase());
	}
}
