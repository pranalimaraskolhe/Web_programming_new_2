package Assigment3;

public class Ques3 {
	   static int count = 0;

	   public static void WebStart(String[] website) {
	      String[] var4 = website;
	      int var3 = website.length;

	      for(int var2 = 0; var2 < var3; ++var2) {
	         String site = var4[var2];
	         if (site.startsWith("www")) {
	            System.out.println(site);
	            ++count;
	         }
	      }

	      System.out.println("Count is : " + count);
	   }

	   public static void main(String[] args) {
	      String[] arr = new String[]{"www.google.com", "www.msn.com", "www.amazon.co.in", "in.answers.yahoo.com", "en.m.wikipedia.com", "codehs.gitbooks.io", "www.coderanch.com"};
	      WebStart(arr);
	   }
	}