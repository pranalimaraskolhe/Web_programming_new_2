package Assigment3;

public class Ques2 {

	public static void nameLength(String[] names) {
		for(String name : names) {
			if(name.length() > 4) {
				System.out.println(name);
			}
		}
	}

	public static void main(String[] args) {
		String[] arr = {"Joy","Meena","Anne","Xi","Veena"};
		nameLength(arr);
	}
	
	
}
