
public class Empl {
	int empid;
	int empsal;
	String empname;
	
	static int counter = 0;
	
	public Empl() {
		this.empid = counter++;
	}
	
	
	public Empl(String empname) {
		this.empid = counter++;
		this.empname = empname;
	}
	
	public Empl(int empsal, String empname) {
		this.empid = counter++;
		this.empsal = empsal;
		this.empname = empname;
		
	}
	
	
	 
	public String toString() {
		return "Empl [empid=" + empid + ", empsal=" + empsal + ", empname=" + empname + " ]";
	}


	public static void main(String[] args) {
		Empl e1 = new Empl();
		Empl e2 = new Empl("Pranali");
		Empl e3 = new Empl(40000,"Harsha");
		
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e3);
	}
	
	
	
}
