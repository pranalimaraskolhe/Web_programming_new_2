package com.cdac.exception;

public class Persons {
	int id;
	String pname, contact;
	public Persons(int id, String pname, String contact) {
		super();
		this.id = id;
		this.pname = pname;
		this.contact = contact;
	}
	
	public String toString() {
		return "Persons [id=" + id + ", pname=" + pname + ", contact=" + contact + "]";
	}
	
	public void updateContact(String contact) throws InvalidContactException {
		if(contact.length() != 10)
			throw new InvalidContactException("hiudkhfdfdjwfolw Excp: contact length must be 10 nos");
		this.contact= contact;
	}
}
