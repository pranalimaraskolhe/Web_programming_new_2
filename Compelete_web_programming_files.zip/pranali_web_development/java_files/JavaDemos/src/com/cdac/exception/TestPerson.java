package com.cdac.exception;

public class TestPerson {
	public static void main(String[] args) {
		Persons p1 = new Persons(101,"Pranali", "125665652625");
		
		try {
			p1.updateContact("9999999995756876889");
		} catch (InvalidContactException e) {
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("In finally block");
		}
		
		System.out.println(p1);
	}
}
