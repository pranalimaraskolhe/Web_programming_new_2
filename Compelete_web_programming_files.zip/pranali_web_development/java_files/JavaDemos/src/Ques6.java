import java.util.Scanner;

public class Ques6 {
	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter Farh: ");
			double farh = sc.nextDouble();
			
			System.out.println(farh);
			double cel = ((farh - 32)* 5/9);
			
			System.out.println("Convert value to celcius is :" + cel);
		}
	}
}
