
public class Ques8 {
	public static void main(String[] args) {
		
		int arr[] = new int[5];
		
		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;
		arr[3] = 15;
		arr[4] = 2;
		
		int sum = 0;
		
		for(int i=0; i<arr.length; i++) {
			sum += arr[i];
		}
		
		int avg = sum/arr.length;
		System.out.println("The sum is" + sum);
		System.out.println("The Average is " + avg);
	}
}
