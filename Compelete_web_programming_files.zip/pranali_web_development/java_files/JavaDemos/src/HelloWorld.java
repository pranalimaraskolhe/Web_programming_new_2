import java.util.Scanner;

public class HelloWorld {
	
	/*public static void main(String[] args) {
		for(int i=1; i<21; i++) {
			if(i%2 ==0) {
				System.out.println(i);
			}
		
		}
	}*/
	//*******************************************
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter age");
		int age = sc.nextInt();
		
		System.out.println("Enter name");
		String sname = sc.next();
		
		
		System.out.println("Age: " + age + " Name: " + sname);
	}
	
	//***********************************************
	
	/*public void greet() {
		System.out.println("Hello User!");
	}
	
	public void greetUser(String uname) {
		System.out.println("Hello " + uname);
	}
	
	public int add(int a, int b) {
		return a+b;
	}
	
	public static void main(String[] args) {
		HelloWorld hw = new HelloWorld();
		hw.greet();
		hw.greetUser("Pranali");
		System.out.println(hw.add(10, 20));
	}*/
	
	

}
