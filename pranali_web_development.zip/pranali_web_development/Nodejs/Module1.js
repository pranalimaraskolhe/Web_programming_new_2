exports.stuname = "Pranali"
exports.age = 23

exports.greetInEng = () =>{
    console.log("Hello " + this.stuname + " "+ this.age)
}

exports.greetInSapnish = () =>{
    console.log("Hola " + this.stuname + " "+ this.age)
}

exports.add = (a,b) => a+b