var express = require('express')

var app = express()

app.get("/",(req, resp)=>{
    resp.sendFile("ques1.html", {root:__dirname})
})

app.get("/process",(req,resp)=>{
    var s1 = req.query.first
    var s2 = req.query.second
    var s3 = req.query.third

    resp.send("<ul><li>"+ s1 + "</li><li>" + s2 + "</li><li>" + s3 + "</li></ul>")
})

app.listen(3000, function(){
    console.log("Server running on http://localhost:3000")
})